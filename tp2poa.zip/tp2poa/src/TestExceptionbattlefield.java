import static org.junit.Assert.*;

import org.junit.Test;


public class TestExceptionbattlefield {

	@Test
	public void test() {
		
		
		ClassArrayList<Integer> a = new ClassArrayList<Integer>(10, 10);
		try {
			a.set(2, 2,25 );
		} catch (ExceptionMatrice e) {

			fail("J'ai recu une exception "+e);
		}
		try {
			assertTrue("erreur",a.get(2,2)==25);
		} catch (ExceptionMatrice e) {

			fail("J'ai recu une exception "+e);
		}
		
		ClassHashMap<Integer> m = new ClassHashMap<Integer>(20,20);
		try {
			m.set(2,2,5);
		} catch (ExceptionMatrice e) {

			fail("J'ai recu une exception "+e);
		}
		/*try {
			assertTrue("erreur",m.get(2, 2)==null);
		} catch (ExceptionMatrice e) {

			fail("J'ai recu une exception "+e);
		}*/
			
		
	}

}

