import java.util.*;
/**
 * 
 * @author imohame
 *
 */
public class ClassHashMap<FieldItem> implements BattleField<FieldItem>{

	int numLigne;
	int numColonne;
	HashMap<Integer, HashMap<Integer, FieldItem>> map;
	
	public ClassHashMap(int l, int c)
	{
		numLigne = l; //hauteur
		numColonne = c;	//largeur
		map = new HashMap<Integer,HashMap<Integer, FieldItem>>();	
	}

	@Override
	public FieldItem get(int l, int c) throws ExceptionMatrice {
		if(l>numLigne || c>numColonne)
		{
			throw new ExceptionMatrice("ERREUR DIMENSION");
		}
		else if(!(map.containsKey(l))){
			return null;
		} 
		else 
		{
				HashMap<Integer, FieldItem> ligne= map.get(c);
				if(!ligne.containsKey(l)){
				return null;
				} else return ligne.get(l);
		}	
	}

	/**
	 * get renvoi la valeur null si la case n'existe pas
	 * si les coordonnees pass�e en parametres sont en dehors de la matrice map, renvoi exception --> dans set aussi
	 */
	@Override
	public void set(int numeroLigne, int numeroColonne, FieldItem data) throws ExceptionMatrice{
		if(numeroLigne<0 || numeroLigne>numLigne || numeroColonne<0 || numeroColonne>numColonne)
		{
			throw new ExceptionMatrice("Valeur Saisie incorrect");
		}
		else if(exists(numeroLigne,numeroColonne))
		{
			HashMap<Integer, FieldItem> b = new HashMap<Integer, FieldItem>();
			map.put(numeroLigne, b);
		}
		map.get(numeroLigne).put(numeroColonne, data);
	}

	
	@Override
	public boolean exists(int numeroLigne, int numeroColonne) {
		if(map.get(numeroLigne).get(numeroColonne)!=null)
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public int height() {
		return numLigne;
	}

	@Override
	public int width() {
		return numColonne;
	}

	
}